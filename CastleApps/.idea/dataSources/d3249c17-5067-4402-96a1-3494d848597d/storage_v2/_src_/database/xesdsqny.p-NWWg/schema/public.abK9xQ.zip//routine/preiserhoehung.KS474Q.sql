create function preiserhoehung() returns void
    language sql
as
$$
UPDATE speise SET preis = FLOOR(preis)+ 0.99;
$$;

alter function preiserhoehung() owner to eryfjzyp;

